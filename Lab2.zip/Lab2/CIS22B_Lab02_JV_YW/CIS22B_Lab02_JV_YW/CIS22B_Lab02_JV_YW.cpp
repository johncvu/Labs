/* Lab2

Description: Work with a partner to develop the four following functions:
i. stringLength  (yours) should duplicate the functionality of strlen (original)
ii. stringNCopy (yours) should mimic strncpy (original)
iii. stringNAdd (yours) should duplicate strncat (original)
iv stringNCompare (yours) should mimic the functionality of strncmp (original)

Authors:	John Vu

IDE Used: Visual Studio 2013
*/
#define _CRT_SECURE_NO_WARNINGS

#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

// Function prototype
size_t stringLength(const char * str);
char * stringNCopy(char * destination, const char * source, size_t num);
char * stringNAdd(char * destination, const char * source, size_t num);
int stringNCompare(const char * str1, const char * str2, size_t num);


//*****************************************************************
// Function main
// Psuedocode:
// Present to user a menu of four choices, or Quit.
// While not Quit
//   Ask user to select one option
//   It depends on which option the user selects, ask user
//   for more information, then call the appropriate function
//   then display the result
// End While
// Exit
//*****************************************************************
int main() {
	const int MAX_CHAR = 1040;				// 1040 is the max number of chars each string will hold
	string userChoice = "";					// Menu choice from user's input
	char string1[MAX_CHAR];					// String 1 to store user's input
	char string2[MAX_CHAR];					// String 2 to store user's input
	int numChars = 0;						// Number of characters to copy, add, or compare
	enum USER_CHOICE { STRING_LENGTH = 1, STRING_N_COPY, STRING_N_ADD, STRING_N_COMPARE };

	cout << "Welcome to the lab 2 program\n";
	// Keep looping until user enters Q to quit
	while (userChoice != "Q" && userChoice != "q") {
		cout << "\nHere is the menu:\n";
		cout << "1. stringLength: to compute the length of a string\n";
		cout << "2. stringNCopy: to copy n chars from string 2 to string 1\n";
		cout << "3. stringNAdd: to append n chars from string 2 to string 1\n";
		cout << "4. stringNCompare: to compare n chars of the two strings\n";
		cout << "Please enter a number of choice (1, 2, 3, 4) or Q to quit: ";
		cin >> userChoice;

		if (userChoice == "Q" || userChoice == "q") {
			cout << "Thank you for using the Lab2 program. Good bye!\n";
		}
		else if (stoi(userChoice) == STRING_LENGTH) {
			cout << "Enter a string: ";
			cin.ignore();			// To delete the CR
			cin.getline(string1, MAX_CHAR, '\n');
			cout << "The length of this string is " << stringLength(string1) << endl;
		}
		else if (stoi(userChoice) == STRING_N_COPY) {
			cout << "Destination string 1 is currently empty. Enter string 2 as source: ";
			cin.ignore();			// To delete the CR
			cin.getline(string2, MAX_CHAR, '\n');
			cout << "Enter a number of chars to copy: ";
			cin >> numChars;
			cout << "The final destination string is: " << stringNCopy(string1, string2, numChars) << endl;
		}
		else if (stoi(userChoice) == STRING_N_ADD) {
			cout << "Enter string 1 as destination: ";
			cin.ignore();			// To delete the CR
			cin.getline(string1, MAX_CHAR, '\n');
			cout << "Enter string 2 as source: ";
			cin.getline(string2, MAX_CHAR, '\n');
			cout << "Enter a number of chars to append: ";
			cin >> numChars;
			cout << "The final destination string is: " << stringNAdd(string1, string2, numChars) << endl;
		}
		else if (stoi(userChoice) == STRING_N_COMPARE) {
			cout << "Enter string 1: ";
			cin.ignore();			// To delete the CR
			cin.getline(string1, MAX_CHAR, '\n');
			cout << "Enter string 2: ";
			cin.getline(string2, MAX_CHAR, '\n');
			cout << "Enter a number of chars to compare: ";
			cin >> numChars;
			int result = stringNCompare(string1, string2, numChars);
			switch (result) {
				case -1:
					cout << "String 1 is smaller than string 2" << endl;
					break;
				case 0:
					cout << "String 1 equals string 2" << endl;
					break;
				case 1:
					cout << "String 1 is greater than string 2" << endl;
					break;
			} // End switch
		} // End if

		// To clear up the content of both string 1 and string 2
		*string1 = NULL;
		*string2 = NULL;
	} // End while
	return(0);
}
//*****************************************************************
// Function stringLength is to return a number of characters in a
// C-string
//
// Psuedocode:
// While char_chk is not NULL
//   Increment counter, and move pointer to the next char
// End While
// Return counter
//
// Parameters:
//		Pointer to a C-string
//
// Returns:
//		A number of characters in a C-string
//*****************************************************************
size_t stringLength(const char * str)
{
	size_t counter = 0;

	while (*str != NULL) {
		counter++;
		str++;
	}
	return counter;
}
//************************************************************************
//* Function stringNCopy copies the first num of characters of source 
//* to destination
//*
//* Psuedocode:
//* Copy one char at a time, until num of chars copied = num, or
//* pointer reaches the end of source
//* Add NULL at end of destination
//* Move pointer back to the beginning of destination
//* Return destination
//* 
//* Parameters:
//*		Pointer to C-string destination
//*		Pointer to const C-string source to be copied from
//*		size_t num - max num of char to be copied from source
//*
//* Returns: 
//*		Pointer to C-string destination
//*
//************************************************************************
char * stringNCopy(char * destination, const char * source, size_t num)
{
	size_t counter = 0;

	while (counter < num && *source != NULL) {
		*destination = *source;
		++destination;
		++source;
		++counter;
	}
	*destination = NULL;
	for (size_t i = 0; i < counter; ++i){
		--destination;
	}
	return destination;
}
//*****************************************************************
// Function stringNAdd is to append num characters from one string to another.
//
// Psuedocode:
// Append one char at a time to destination, until num of chars copied = num, or
// pointer reaches the end of source
// Add NULL at end of destination
// Move pointer back to the beginning of destination
// Return destination
//
// Parameters:
//		Pointer to C-string destination
//		Pointer to const C-string source to be copied from
//		size_t num - max num of char to be copied from source
//
// Returns:
//		Pointer to C-string destination
//		
//*****************************************************************
char * stringNAdd(char * destination, const char * source, size_t num)
{
	size_t numToAppend = 0;
	size_t destLength = stringLength(destination);

	destination += destLength;
	while (numToAppend < num && *source != NULL) {
		// Add one char at a time, until num of chars copied = num, or
		// pointer reaches the end of source
		*destination = *source;
		++destination;
		++source;
		++numToAppend;
	}
	*destination = NULL;
	for (size_t i = 0; i < numToAppend + destLength; ++i){
		--destination;
	}
	return destination;
}
//************************************************************************
//* Function stringNCompare compares up to first num characters of 
//* C-string 1 to those of C-string 2
//*
//* Psuedocode:
//* Compare one char of both strings at a time, until num of 
//* chars compared = num, or two chars do not match
//* Return -1 if str1 < str2
//* Return 1 if str1 > str2
//* Return 0 if str1 = str2
//*
//* Parameters:
//*		Pointer to const C-string 1
//*		Pointer to const C-string 2
//*		size_t num - max num of char to be compared
//*
//* Returns:
//*    -1 the first character that does not match has a lower value in str1 than in str2
//*    1 the first character that does not match has a greater value in str1 than in str2
//*    0 contents are equal
//*
//************************************************************************
int stringNCompare(const char * str1, const char * str2, size_t num)
{
	size_t counter = 0;

	while (counter < num) {
		// If first char that does not match and has a lower value in str1 than in str2
		if (*str1 < *str2) {	
			return -1;
		}
		// If first char that does not match and has a greater value in str1 than in str2
		else if (*str1 > *str2) {
			return 1;
		}
		++str1;
		++str2;
		++counter;
	}
	// If the program gets through the while loop and gets here, the two strings are equal
	return 0;
}
