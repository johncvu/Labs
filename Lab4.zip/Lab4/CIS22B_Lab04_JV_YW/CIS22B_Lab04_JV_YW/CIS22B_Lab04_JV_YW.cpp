/* Lab4

Description:
1. Write templates for two functions minimum and maximum.
2. Wtite a function template that accepts an argument, and returns its absolute value.
3. Write a template for a function called total.

Authors:	John Vu


IDE Used: Visual Studio 2013
*/
#define _CRT_SECURE_NO_WARNINGS

#include "templates.h"

#include <string>
#include <iomanip>
#include <iostream>

using namespace std;

//*****************************************************************
// Function main
// Psuedocode:
//		Display the results of Minimum, Maximum, and Absolute 
//		functions with various different data types.
//		Ask user for number of arguments to enter
//		Ask user to select data type (1 - 3)
//		If selection is not ( 1 - 3), keep asking for a valid entry
//		Display the running total
// Exit
//*****************************************************************

int main()
{
	/////////////////////////////////////

	/*  testing the minimum, maximum
	and functions          */

	/////////////////////////////////////
	int num1 = 1,
		num2 = 3;

	double dnum1 = 1.5,
		dnum2 = 3.7;

	char char1 = 'd',
		char2 = 'g';

	string str1 = "abc",
		str2 = "xyz";

	cout << "Minimum function with two int " << num1 << " & " << num2 << " returns: " << minimum(num1, num2) << endl;
	cout << "Minimum function with two double " << dnum1 << " & " << dnum2 << " returns: " << minimum(dnum1, dnum2) << endl;
	cout << "Minimum function with two chars " << char1 << " & " << char2 << " returns: " << minimum(char1, char2) << endl;
	cout << "Minimum function with two strings " << str1 << " & " << str2 << " returns: " << minimum(str1, str2) << endl;
	cout << "Maximum function with int and double " << dnum2 << " & " << num2 << " returns: " << 
		maximum(dnum2, num2) << endl << endl << endl;



	/////////////////////////////////////

	/*  testing the absolute functions          */

	/////////////////////////////////////
	num1 = 3;
	num2 = -3;

	dnum1 = 1.5;
	dnum2 = -1.5;

	cout << "The absolute value of " << num1 << " is: " << absolute(num1) << endl;
	cout << "The absolute value of " << num2 << " is: " << absolute(num2) << endl;
	cout << "The absolute value of " << dnum1 << " is: " << absolute(dnum1) << endl;
	cout << "The absolute value of " << dnum2 << " is: " << absolute(dnum2) << endl << endl << endl;


	/////////////////////////////////////////////////

	/* getting user input for the "total" function */

	/////////////////////////////////////////////////

	string userInput = "";
	cout << "Please enter how many number of values to be read in: ";
	cin >> userInput;
	while (stoi(userInput) <= 0){
		cout << "Input invalid. Please enter a valid integer larger than 0: ";
		cin >> userInput;
	}
	int size = stoi(userInput);

	string userSelect = "";
	cout << "Please choose from 1-3 for the data type: " << endl
		<< "1. Integer" << endl
		<< "2. Double" << endl
		<< "3. String" << endl
		<< "Enter your choice here: ";
	cin >> userSelect;
	while (stoi(userSelect) < 1 || stoi(userSelect) > 3) {
		cout << "Input invalid. Please enter an integer between 1-3: ";
		cin >> userSelect;
	}
	int option = stoi(userSelect);

	enum DATATYPE { INT = 1, DOUBLE, STR };

	//////////////////////////////////////////////////

	/*  testing function with different data types  */

	//////////////////////////////////////////////////
	int *inputInt = new int[size];
	double *inputDouble = new double[size];
	string *inputString = new string[size];

	switch (option) {
		case INT:
			for (int i = 0; i<size; i++){
				cout << "Please enter data " << i + 1 << ": ";
				cin >> inputInt[i];
			}

			cout << "The total of the input is " << total(inputInt, size) << endl;
			break;

		case DOUBLE:
			for (int i = 0; i<size; i++){
				cout << "Please enter data " << i + 1 << ": ";
				cin >> inputDouble[i];
			}
			cout << "The total of the input is " << total(inputDouble, size) << endl;
			break;

		case STR:
			for (int i = 0; i<size; i++){
				cout << "Please enter " << i + 1 << ": ";
				cin >> inputString[i];
			}
			cout << "The total of the input is " << total(inputString, size) << endl;
			break;

		default:
			break;
	}

	delete []inputInt;
	delete []inputDouble;
	delete []inputString;

	return 0;
}