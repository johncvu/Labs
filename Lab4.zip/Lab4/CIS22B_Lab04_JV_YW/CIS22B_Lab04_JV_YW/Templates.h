#ifndef TEMPLATES_H
#define TEMPLATES_H

template <class T>
T minimum(T num1, T num2){
	if (num1<num2){
		return num1;
	}
	return num2;
}

template <class T1, class T2>
double maximum(T1 num1, T2 num2){
	if (num1>num2){
		return double(num1);
	}

	return double(num2);
}

template <class T>
T absolute(T num1){
	if (num1<0){
		return (-1)*num1;
	}
	return num1;
}

template <class T>
T total(T* arr, int size){
	T runningTotal = T();
	for (int i = 0; i < size; i++){
		runningTotal = runningTotal + arr[i];
	}
	return runningTotal;
}

#endif