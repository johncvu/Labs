// Lab1
/*
Description: This program reads in the contents of a text file up to a maximum of 1024 words.
When reading the file contents, it can discard words that are single characters to avoid 
symbols, special characters etc.  Sort the words read in ascending order in an array
using the Selection Sort algorithm implemented in its own function.  Search any item input by
user in the sorted list using the Binary Search algorithm implemented in its own function.
*/
//
// Author: John Vu
//
//
// IDE Used: Visual Studio 2013
//


#include <cstdlib>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

// Function prototype
int binarySearch(string[], int, string);
void selectionSort(string[], int);
double fallingDistance(int);


//*****************************************************************
// Function main
// Psuedocode:
// Prompt user for full path and file name for input and output
// While not EOF and counter < 1024
//   Read one word at a time
//   If word is ok
//     increment the counter
//     add to the array
//   end If
// End While
// Close file
// Call selectionSort()
// Promtp user for word(s) to search
// Call binarySearch()
// Prompt user if the word is found or not
// Ask to user to continue or quit
//*****************************************************************
int main() {
	// Declare constants
	const int MAX_WORDS = 1024;				// Maximum number of words to read in
	const int OPEN_ERROR = 1;				// Constant cannot open file error code
	const int READ_ERROR = 2;				// Constant cannot read file error code

	string inFileName;						// File name for input
	string outFileName;						// File name for output
	string wordArray[MAX_WORDS];			// Array to hold words from the input file
	string wordReadIn = "";					// String to read one word at a time
	string outputString = "";				// String to hold message for console output and file output
	string wordToSearch = "";				// String variable to hold word to search
	char userContinue = 'Y';				// User's input to continue or not
	int wordCounter = 0;					// Counter to keep track of how many words read in
	bool readOk = true;						// Boolean readOk to check each word read in from the file

	ifstream inputFile;						// Create an object for input file stream
	ofstream outFile;						// Object for output file stream
	
	// Promtp user for location of input file
	cout << "Welcome to the lab 1 program\n";
	cout << "Please enter the full path and file name to read in: ";
	cin >> inFileName;
	// Open file for input
	inputFile.open(inFileName);
	// Check to see if file opens successfully, if not then exit with OPEN_ERROR code
	if (inputFile.fail()) {
		cout << "Could not open file " << inFileName << ". Please make sure the file exists," <<
			" and the path is correct\n";
		exit(OPEN_ERROR);
	}

	// Promtp user for location of output file
	cout << "Enter the full path and file name for output: ";
	cin >> outFileName;
	// Open file for output
	outFile.open(outFileName);
	// Check to see if file opens successfully, if not then exit with OPEN_ERROR code
	if (outFile.fail()) {
		cout << "Could not open file " << outFileName << " for output\n";
		exit(OPEN_ERROR);
	}

	// Read data from the input file
	while (!inputFile.eof() && wordCounter < MAX_WORDS) {
		readOk = inputFile >> wordReadIn ? true : false;
		// Check to see if reads data successfully, if not then exit with READ_ERROR code
		if (!readOk) {
			outputString = "Could not read all the data from file " + inFileName + "\n";
			cout << outputString;
			outFile << outputString;
			// Close the input file
			inputFile.close();
			exit(READ_ERROR);
		}
		if (wordReadIn.length() > 1) {		// Word has more than one character
			wordArray[wordCounter] = wordReadIn;
			++wordCounter;
		}
	}	// End while
	// Close the input file
	inputFile.close();
	// Call function selectionSort to sort the array
	selectionSort(wordArray, wordCounter);
	// Ask user for word(s) to search
	while (userContinue == 'Y' || userContinue == 'y') {
		outputString = "Enter a word to search: ";
		cout << outputString;
		cin >> wordToSearch;
		outFile << outputString + wordToSearch + "\n";
		// Call binarySearch to search for the word
		int indexFound = binarySearch(wordArray, wordCounter, wordToSearch);
		if (indexFound != -1)
			outputString = "The word " + wordToSearch + " is found at index " + to_string(indexFound) + "\n";
		else
			outputString = "The word " + wordToSearch + " is not in the array\n";
		cout << outputString;
		outFile << outputString;
		// Ask user to continue or not
		outputString = "Search another word (Y or N)? ";
		cout << outputString;
		cin >> userContinue;
		outFile << outputString + userContinue + "\n";
	}
	// User quits, thank and goodbye
	outputString = "Thank you for using the lab1 program. Goodbye.\n\n";
	cout << outputString;
	outFile << outputString;

	// Print the array to the output file
	for (int index = 0; index < wordCounter; ++index) {
		outFile << wordArray[index] + "\n";
	}
	// Close the outfile
	outFile.close();
	return(0);
}

//*****************************************************************
// Function binarySearch is to search for an item in the array of strings.
// Psuedocode:
// Set first index to 0.
// Set last index to the last subscript in the array.
// Set found to false.
// Set position to - 1.
// While found is not true and first is less than or equal to last
//   Set middle to the subscript half - way between array[first] and array[last].
//   If array[middle] equals the desired value
//     Set found to true.
//     Set position to middle.
//   Else If array[middle] is greater than the desired value
//     Set last to middle - 1.
//   Else
//     Set first to middle + 1.
//   End If.
// End While.
// Return position.
//
// Parameters:
//		array of strings
//		size of the array
//      value to search
//
// Returns:
//		position of the search value if found, else return -1
//*****************************************************************
int binarySearch(string array[], int size, string value)
{
	int first = 0,						// First array element
		last = size - 1,				// Last array element
		middle,							// Mid point of search
		position = -1;					// Position of search value
	bool found = false;					// Flag

	while (!found && first <= last)
	{
		middle = (first + last) / 2;	// Calculate mid point
		if (array[middle] == value)		// If value is found at mid
		{
			found = true;
			position = middle;
		}
		else if (array[middle] > value) // If value is in lower half
			last = middle - 1;
		else
			first = middle + 1;			// If value is in upper half
	}
	return position;
}
//*****************************************************************
// Function SelectionSort is to sort an array of strings in ascending order.
// Psuedocode:
// Locate smallest element in array � swap it with element at position 0
// Locate second smallest element � swap it with element at position 1
// Continue process until array sorted
//
// Parameters:
//		array of strings
//		size of the array
//
// Returns:
//		None
//*****************************************************************
void selectionSort(string array[], int size)
{
	int startScan, minIndex;
	string minValue;

	for (startScan = 0; startScan < (size - 1); ++startScan)
	{
		minIndex = startScan;
		minValue = array[startScan];
		for (int index = startScan + 1; index < size; ++index)
		{
			if (array[index] < minValue)
			{
				minValue = array[index];
				minIndex = index;
			}
		}
		array[minIndex] = array[startScan];
		array[startScan] = minValue;
	}
}
