#include "TeamLeader.h"


TeamLeader::TeamLeader(string empName, int number, string joinDate, double hourlyPay, int session, double bonus,
	double minimum, double attended):ProductionWorker(empName, number, joinDate, hourlyPay, session) {
	if (attended < 8.0) {
		throw "IncompleteTraining";
	}
	else {
		monthlyBonus = bonus;
		minHour = minimum;
		attendedHour = attended;
	}
}
//mutator
void TeamLeader::setMBonus(double bonus) {
	bonus = monthlyBonus;
}
void TeamLeader::setMHour(double minimum) {
	minHour = minimum;
}
void TeamLeader::setHoursTrainingAttended(int hoursAttended) {
	if (hoursAttended < 8.0) {
		throw "IncompleteTraining";
	}
	else {
		attendedHour = hoursAttended;
	}
}

//accessor
double TeamLeader::getMBonus() const {
	return monthlyBonus;
}
double TeamLeader::getMinimumHour() const {
	return minHour;
}
double TeamLeader::getAttendedHour() const {
	return attendedHour;
}
void TeamLeader::getPayAmount() {
	cout << "Hourly rate: " << getRate() << endl <<
		"Monthly bonus: " << monthlyBonus << endl;
}

TeamLeader::~TeamLeader(){

}