/*
Name: John Vu 

CIS22B MakeupLab (replace Lab 3)

IDE : visual studio 2013

pseudocode:
1. create Employee class with 3 private member data (name, idNumber, hired date) and contructors, mutator, accessor

2. create ProductionWorker class derived from Employee class, add 2 private member data (shift, salary),
overload constructor with more parameters, add mutator and accessor for the 2 member data

3. create ShiftSupervisor class derived from Employee class, add 2 private member data (annual salary, annual bonus),
overload constructor with more parameters, add mutator and accessor

4. create TeamLeader class derived from Employee class, add 3 private member data (monthly bonus, minimum trainning hours, attended training hours),
overload constructor with more parameters, add mutator and accessor
the attended hour variable can be modified by calling addhour()

once every object is created, the program will display information .

Implement Throw, Try, and Catch.

*/

#define _CRT_SECURE_NO_WARNINGS

#include <iomanip>
#include <iostream>
#include <string>
#include <time.h>
#include "Employee.h"
#include "ProductionWorker.h"
#include "ShiftSupervisor.h"
#include "TeamLeader.h"

using namespace std;

int main() {
	string empName;
	int empNum;
	string hireDate;
	int shift;
	double hourlyRate;
	double salary;
	double bonus;
	double hoursTrainingRequired;
	double hoursTrainingAttended;
	string userChoice = "";					// Menu choice from user's input
	enum USER_CHOICE { REGULAR_EMPLOYEE = 1, PRODUCTION_WORKER, SHIFT_SUPERVISOR, TEAM_LEADER };

	cout << "Welcome to the makeup lab program\n";
	// Keep looping until user enters Q to quit
	while (userChoice != "Q" && userChoice != "q") {
		cout << "\nEmployee Menu:\n";
		cout << "1. Regular employee\n";
		cout << "2. Production worker\n";
		cout << "3. Shift supervisor\n";
		cout << "4. Team leader\n";
		cout << "Please select a type of employee (1, 2, 3, 4) or Q to quit: ";
		cin >> userChoice;

		if (userChoice == "Q" || userChoice == "q") {
			cout << "Thank you for running the makeup lab.  Goodbye!\n";
		}
		else if (stoi(userChoice) == REGULAR_EMPLOYEE) {
			cout << "Enter the employee's name: ";
			cin.ignore();			// To delete the CR
			getline(cin, empName);
			cout << "Employee's number: ";
			cin >> empNum;
			cout << "Hire date: ";
			cin >> hireDate;
			try
			{
				Employee * regularEmp = new Employee(empName, empNum, hireDate);

				cout << "\nEmployee number: " << regularEmp->getNumber() << " (Regular Employee)\n" <<
					"Name: " << regularEmp->getName() << endl <<
					"Hire date: " << regularEmp->getDate() << endl << endl;

				delete regularEmp;
			}
			catch (const char *errorCode)
			{
				cout << errorCode << endl << endl;
			}
		}
		else if (stoi(userChoice) == PRODUCTION_WORKER) {
			cout << "Enter the employee's name: ";
			cin.ignore();			// To delete the CR
			getline(cin, empName);
			cout << "Employee's number: ";
			cin >> empNum;
			cout << "Hire date: ";
			cin >> hireDate;
			cout << "Shift (1 or 2): ";
			cin >> shift;
			cout << "Hourly rate: ";
			cin >> hourlyRate;
			try
			{
				ProductionWorker * prodWorker = new ProductionWorker(empName, empNum, hireDate, hourlyRate, shift);

				cout << "\nEmployee number: " << prodWorker->getNumber() << " (Production Worker)\n" <<
					"Name: " << prodWorker->getName() << endl <<
					"Hire date: " << prodWorker->getDate() << endl <<
					"Shift: " << prodWorker->getShift() << endl <<
					"Hourly rate: " << prodWorker->getRate() << endl;
				prodWorker->getPayAmount();
				cout << endl;

				delete prodWorker;
			}
			catch (const char *errorCode)
			{
				cout << errorCode << endl << endl;
			}
		}
		else if (stoi(userChoice) == SHIFT_SUPERVISOR) {
			cout << "Enter the employee's name: ";
			cin.ignore();			// To delete the CR
			getline(cin, empName);
			cout << "Employee's number: ";
			cin >> empNum;
			cout << "Hire date: ";
			cin >> hireDate;
			cout << "Annual salary: ";
			cin >> salary;
			cout << "Annual Bonus: ";
			cin >> bonus;
			try
			{
				ShiftSupervisor * supervisor = new ShiftSupervisor(empName, empNum, hireDate, salary, bonus);

				cout << "Employee number: " << supervisor->getNumber() << " (Shift Supervisor)\n" <<
					"Name: " << supervisor->getName() << endl <<
					"Hire date: " << supervisor->getDate() << endl;
				supervisor->getPayAmount();
				cout << endl;

				delete supervisor;
			}
			catch (const char *errorCode)
			{
				cout << errorCode << endl << endl;
			}
		}
		else if (stoi(userChoice) == TEAM_LEADER) {
			cout << "Enter the employee's name: ";
			cin.ignore();			// To delete the CR
			getline(cin, empName);
			cout << "Employee's number: ";
			cin >> empNum;
			cout << "Hire date: ";
			cin >> hireDate;
			cout << "Shift (1 or 2): ";
			cin >> shift;
			cout << "Hourly rate: ";
			cin >> hourlyRate;
			cout << "Monthly Bonus: ";
			cin >> bonus;
			cout << "Hours Trainning Required: ";
			cin >> hoursTrainingRequired;
			cout << "Hours Trainning Attended: ";
			cin >> hoursTrainingAttended;
			try
			{
				TeamLeader * leader = new TeamLeader(empName, empNum, hireDate, hourlyRate, shift,
					bonus, hoursTrainingRequired, hoursTrainingAttended);

				cout << "\nEmployee number: " << leader->getNumber() << " (Team Leader)\n" <<
					"Name: " << leader->getName() << endl <<
					"Hire date: " << leader->getDate() << endl <<
					"Shift: " << leader->getShift() << endl;
				leader->getPayAmount();
				cout <<	"Number of trainning hours required: " << leader->getMinimumHour() << endl <<
					"Number of trainning hours attended: " << leader->getAttendedHour() << endl << endl;

				delete leader;
			}
			catch (const char *errorCode)
			{
				cout << errorCode << endl << endl;
			}
		} // End if
	} // End while

	system("pause");

	return 0;
}