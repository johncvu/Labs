#ifndef SHIFTSUPERVISOR_H
#define SHIFTSUPERVISOR_H

#include <string>
#include <iostream>
#include <iomanip>
#include "Employee.h"
using namespace std;

class ShiftSupervisor : public Employee {
private:
	double annualSalary, annualBonus;

public:
	//consturctors

	ShiftSupervisor(string , int, string , double , double) ;

	//mutator
	void setSalary(double);
	void setBonus(double);

	//accessor
	double getSalary() const;
	double getBonus() const;

	void getPayAmount();
	~ShiftSupervisor();
};

#endif
