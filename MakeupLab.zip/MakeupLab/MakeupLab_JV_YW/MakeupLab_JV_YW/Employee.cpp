#define _CRT_SECURE_NO_WARNINGS
#include "Employee.h"
using namespace std;

Employee::Employee(string employeeName , int employeeID, string employeeDate) {
	if (employeeID < 0 || employeeID > 9999) {
		throw "InvalidEmployeeNumber";
	}
	else {
		name = employeeName;
		idNumber = employeeID;
		hireDate = employeeDate;
	}
}

//mutator
void Employee::setName(string empName) {
	name = empName;
}
void Employee::setDate(string joinDate) {
	hireDate = joinDate;
}

void Employee::setIdNumber(int number) {
	if (number < 0 || number > 9999)
		throw "InvalidEmployeeNumber";
	idNumber = number;
}
//accessor
string Employee::getName() {
	return name;
}
int Employee::getNumber() {
	return idNumber;
}
	
string Employee::getDate() {
	return hireDate;
}

void Employee::getPayAmount() {

}

Employee::~Employee() {

}
