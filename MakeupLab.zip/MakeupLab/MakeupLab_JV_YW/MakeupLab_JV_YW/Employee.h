#define _CRT_SECURE_NO_WARNINGS
#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>
#include <iostream>
#include <iomanip>

using namespace std;
class Employee{

protected:
	string name;
	int idNumber; //running number for employee
	string hireDate;

public:
	Employee(string, int, string);

	//mutator - further define in respective cpp file
	void setName(string );
	void setDate(string );
	void setIdNumber(int );
	//accessor - further define in respective cpp file
	string getName();
	int getNumber();
	string getDate();

	virtual void getPayAmount() ;
	~Employee();
};

#endif