
#include "ProductionWorker.h"

ProductionWorker::ProductionWorker(string empName, int number, string joinDate, double hourlyPay, int session):Employee(empName, number, joinDate) {
	if (session != 1 && session != 2) {
		throw "InvalidShift";
	} else if (hourlyPay < 0) {
		throw "InvalidPayRate";
	} else {
		payRate = hourlyPay;
		shift = session;
	}
}

void ProductionWorker::setRate(double hourlyPay) {
	if (hourlyPay < 0) {
		throw "InvalidPayRate";
	}
	else {
		payRate = hourlyPay;
	}
}

void ProductionWorker::setShift(int session) {
	if (session != 1 && session != 2) {
		throw "InvalidShift";
	} else {
		shift = session;
	}
}

double ProductionWorker::getRate() const {
	return payRate;
}
int ProductionWorker::getShift() const {
	return shift;
}

void ProductionWorker::getPayAmount() {
	double payAmount = payRate * shift;
	cout << "The total pay: $" << payAmount << endl;
}

ProductionWorker::~ProductionWorker() {

}