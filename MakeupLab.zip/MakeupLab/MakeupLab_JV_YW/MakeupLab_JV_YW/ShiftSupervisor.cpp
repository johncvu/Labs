#include "ShiftSupervisor.h"

ShiftSupervisor::ShiftSupervisor(string empName, int number, string joinDate, double salary, double bonus):Employee(empName, number, joinDate) {
	annualSalary = salary;
	annualBonus = bonus;
}
//mutator
void ShiftSupervisor::setSalary(double salary) {
	annualSalary = salary;
}
void ShiftSupervisor::setBonus(double bonus) {
	annualBonus = bonus;
}

//accessor
double ShiftSupervisor::getSalary() const {
	return annualSalary;
}

double ShiftSupervisor::getBonus() const {
	return annualBonus;
}

void ShiftSupervisor::getPayAmount() {
	cout << "Annual salary: $" << annualSalary << endl
		<< "Annual bonus: $" << annualBonus << endl;
}

ShiftSupervisor::~ShiftSupervisor(){

}