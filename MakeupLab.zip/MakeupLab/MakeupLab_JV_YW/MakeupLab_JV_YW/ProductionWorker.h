#ifndef PRODUCTIONWORKER_H
#define PRODUCTIONWORKER_H

#include <string>
#include <iostream>
#include <iomanip>
#include "Employee.h"
using namespace std;

class ProductionWorker : public Employee {
private:
	double payRate;
	int shift;

public:
	//constructor
	ProductionWorker(string, int, string, double, int);
	
	//mutator - further define in respective cpp file
	void setRate(double);
	void setShift(int);

	//accessor - further define in respective cpp file
	double getRate() const;
	int getShift() const;

	void getPayAmount();
	~ProductionWorker();
};


#endif