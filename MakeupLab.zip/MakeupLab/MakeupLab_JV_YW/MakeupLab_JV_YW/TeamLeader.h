#ifndef TEAMLEADER_H
#define TEAMLEADER_H

#include <string>
#include <iostream>
#include <iomanip>
#include "Employee.h"
#include "ProductionWorker.h"
using namespace std;

class TeamLeader:public ProductionWorker { 
private:
	double monthlyBonus;
	double minHour;
	double attendedHour;

public:
	//constructor
	TeamLeader(string, int, string, double, int, double, double, double);

	//mutator - further define in respective cpp file
	void setMBonus(double);
	void setMHour(double);
	void setHoursTrainingAttended(int);

	//accessor - further define in respective cpp file
	double getMBonus() const;
	double getMinimumHour() const;
	double getAttendedHour() const;

	void getPayAmount();
	~TeamLeader();
};

#endif