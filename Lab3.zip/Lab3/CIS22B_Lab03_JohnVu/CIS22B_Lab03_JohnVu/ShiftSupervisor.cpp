#include "ShiftSupervisor.h"

ShiftSupervisor::ShiftSupervisor()
{
	annualSalary = 0.0;
	annualBonus = 0.0;
}
ShiftSupervisor::ShiftSupervisor(double salary, double bonus)
{
	annualSalary = salary;
	annualBonus = bonus;
}
void ShiftSupervisor::setSalary(double salary)
{
	annualSalary = salary;
}
void ShiftSupervisor::setBonus(double bonus)
{
	annualBonus = bonus;
}
double ShiftSupervisor::getSalary() const
{
	return annualSalary;
}
double ShiftSupervisor::getBonus() const
{
	return annualBonus;
}