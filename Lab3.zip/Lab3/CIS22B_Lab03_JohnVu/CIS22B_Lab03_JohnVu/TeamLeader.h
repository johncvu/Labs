#ifndef TEAMLEADER_H
#define TEAMLEADER_H
#include "ProductionWorker.h"

class TeamLeader : public ProductionWorker
{
private:
	double monthlyBonus;
	int numHoursTrainingRequired;
	int numHoursTrainingAttended;
public:
	TeamLeader();
	TeamLeader(double, int, int);
	void setMonthlyBonus(double);
	void setNumHoursTrainingRequired(int);
	void setNumHoursTrainingAttended(int);
	double getMonthlyBonus() const;
	int getNumHoursTrainingRequired() const;
	int getNumHoursTrainingAttended() const;
};
#endif 