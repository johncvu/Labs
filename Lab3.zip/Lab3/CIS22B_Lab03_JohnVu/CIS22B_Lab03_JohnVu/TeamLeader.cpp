#include "TeamLeader.h"

TeamLeader::TeamLeader()
{
	monthlyBonus = 0.0;
	numHoursTrainingRequired = 0;
	numHoursTrainingAttended = 0;
}
TeamLeader::TeamLeader(double inBonus, int hoursRequired, int hoursAttended)
{
	monthlyBonus = inBonus;
	numHoursTrainingRequired = hoursRequired;
	numHoursTrainingAttended = hoursAttended;
}
void TeamLeader::setMonthlyBonus(double inBonus)
{
	monthlyBonus = inBonus;
}
void TeamLeader::setNumHoursTrainingRequired(int hoursRequired)
{
	numHoursTrainingRequired = hoursRequired;
}
void TeamLeader::setNumHoursTrainingAttended(int hoursAttended)
{
	numHoursTrainingAttended = hoursAttended;
}
double TeamLeader::getMonthlyBonus() const
{
	return monthlyBonus;
}
int TeamLeader::getNumHoursTrainingRequired() const
{
	return numHoursTrainingRequired;
}
int TeamLeader::getNumHoursTrainingAttended() const
{
	return numHoursTrainingAttended;
}