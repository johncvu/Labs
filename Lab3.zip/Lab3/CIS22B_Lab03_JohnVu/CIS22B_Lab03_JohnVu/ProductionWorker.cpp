#include "ProductionWorker.h"

ProductionWorker::ProductionWorker()
{
	shift = 1;
	hourlyPayRate = 0.0;
}
ProductionWorker::ProductionWorker(int inShift, double inRate)
{
	shift = inShift;
	hourlyPayRate = inRate;
}
void ProductionWorker::setShift(int inShift)
{
	shift = inShift;
}
void ProductionWorker::setHourlyPayRate(double inRate)
{
	hourlyPayRate = inRate;
}
int ProductionWorker::getShift() const
{
	return shift;
}
double ProductionWorker::getHourlyPayRate() const
{
	return hourlyPayRate;
}