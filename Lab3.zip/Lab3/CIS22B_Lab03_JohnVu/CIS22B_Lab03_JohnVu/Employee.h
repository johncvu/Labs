#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include <string>
using namespace std;

class Employee
{
private:
	string empName;
	int empNumber;
	string hireDate;

public:
	Employee();
	Employee(string, int, string);
	void setEmpName(string);
	void setEmpNumber(int);
	void setHireDate(string);
	string getEmpName() const;
	int getEmpNumber() const;
	string getHireDate() const;
};
#endif 