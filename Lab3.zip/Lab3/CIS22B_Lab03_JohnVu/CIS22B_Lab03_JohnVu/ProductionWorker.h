#ifndef PRODUCTIONWORKER_H
#define PRODUCTIONWORKER_H
#include "Employee.h"

class ProductionWorker : public Employee
{
private:
	int shift;
	double hourlyPayRate;
public:
	ProductionWorker();
	ProductionWorker(int, double);
	void setShift(int);
	void setHourlyPayRate(double);
	int getShift() const;
	double getHourlyPayRate() const;
};
#endif 