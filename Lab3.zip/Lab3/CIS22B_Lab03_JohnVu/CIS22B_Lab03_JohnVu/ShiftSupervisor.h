#ifndef SHIFTSUPERVISOR_H
#define SHIFTSUPERVISOR_H
#include "Employee.h"

class ShiftSupervisor : public Employee
{
private:
	double annualSalary;
	double annualBonus;
public:
	ShiftSupervisor();
	ShiftSupervisor(double, double);
	void setSalary(double);
	void setBonus(double);
	double getSalary() const;
	double getBonus() const;
};
#endif 