#include "Employee.h"

Employee::Employee()
{
	empName = "";
	empNumber = 0;
	hireDate = "";
}
Employee::Employee(string inName, int inNum, string inDate)
{
	empName = inName;
	empNumber = inNum;
	hireDate = inDate;
}
void Employee::setEmpName(string inName)
{
	empName = inName;
}
void Employee::setEmpNumber(int num)
{
	empNumber = num;
}
void Employee::setHireDate(string inDate)
{
	hireDate = inDate;
}
string Employee::getEmpName() const
{
	return empName;
}
int Employee::getEmpNumber() const
{
	return empNumber;
}
string Employee::getHireDate() const
{
	return hireDate;
}

