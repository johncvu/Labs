/* Lab3

Description: Design four classes of Employees: Employee, ProductionWorker, 
	ShiftSupervisor, and TeamLeader.  Write a main prpogram to test these classes.

Authors:	John Vu


IDE Used: Visual Studio 2013
*/
#define _CRT_SECURE_NO_WARNINGS

#include "Employee.h"
#include "ProductionWorker.h"
#include "ShiftSupervisor.h"
#include "TeamLeader.h"

#include <string>
#include <iomanip>
#include <iostream>

using namespace std;

//*****************************************************************
// Function main
// Psuedocode:
// Present to user a menu of four choices, or Quit.
// While not Quit
//   Ask user to select one option
//   It depends on which option the user selects, ask user
//   for more information
// End While
// Print out the results
// Exit
//*****************************************************************

int main()
{
	string empName;
	int empNum;
	string hireDate;
	int shift;
	double hourlyRate;
	double salary;
	double bonus;
	int hoursTrainingRequired;
	int hoursTrainingAttended;

	Employee regularEmp;
	ProductionWorker prodWorker;
	ShiftSupervisor supervisor;
	TeamLeader leader;

	string userChoice = "";					// Menu choice from user's input
	enum USER_CHOICE { REGULAR_EMPLOYEE = 1, PRODUCTION_WORKER, SHIFT_SUPERVISOR, TEAM_LEADER };

	cout << "Welcome to the lab 3 program\n";
	// Keep looping until user enters Q to quit
	while (userChoice != "Q" && userChoice != "q") {
		cout << "\nEmployee Menu:\n";
		cout << "1. Regular employee\n";
		cout << "2. Production worker\n";
		cout << "3. Shift supervisor\n";
		cout << "4. Team leader\n";
		cout << "Please select a type of employee (1, 2, 3, 4) or Q to quit: ";
		cin >> userChoice;

		if (userChoice == "Q" || userChoice == "q") {
			cout << "User's input ends\n";
		}
		else if (stoi(userChoice) == REGULAR_EMPLOYEE) {
			cout << "Enter the employee's name: ";
			cin.ignore();			// To delete the CR
			getline(cin, empName);
			cout << "Employee's number: ";
			cin >> empNum;
			cout << "Hire date: ";
			cin >> hireDate;
			regularEmp.setEmpName(empName);
			regularEmp.setEmpNumber(empNum);
			regularEmp.setHireDate(hireDate);
		}
		else if (stoi(userChoice) == PRODUCTION_WORKER) {
			cout << "Enter the employee's name: ";
			cin.ignore();			// To delete the CR
			getline(cin, empName);
			cout << "Employee's number: ";
			cin >> empNum;
			cout << "Hire date: ";
			cin >> hireDate;
			cout << "Shift (1 or 2): ";
			cin >> shift;
			cout << "Hourly rate: ";
			cin >> hourlyRate;
			prodWorker.setShift(shift);
			prodWorker.setHourlyPayRate(hourlyRate);
			prodWorker.setEmpName(empName);
			prodWorker.setEmpNumber(empNum);
			prodWorker.setHireDate(hireDate);
		}
		else if (stoi(userChoice) == SHIFT_SUPERVISOR) {
			cout << "Enter the employee's name: ";
			cin.ignore();			// To delete the CR
			getline(cin, empName);
			cout << "Employee's number: ";
			cin >> empNum;
			cout << "Hire date: ";
			cin >> hireDate;
			cout << "Annual salary: ";
			cin >> salary;
			cout << "Annual Bonus: ";
			cin >> bonus;
			supervisor.setSalary(salary);
			supervisor.setBonus(bonus);
			supervisor.setEmpName(empName);
			supervisor.setEmpNumber(empNum);
			supervisor.setHireDate(hireDate);
		}
		else if (stoi(userChoice) == TEAM_LEADER) {
			cout << "Enter the employee's name: ";
			cin.ignore();			// To delete the CR
			getline(cin, empName);
			cout << "Employee's number: ";
			cin >> empNum;
			cout << "Hire date: ";
			cin >> hireDate;
			cout << "Shift (1 or 2): ";
			cin >> shift;
			cout << "Hourly rate: ";
			cin >> hourlyRate;
			cout << "Monthly Bonus: ";
			cin >> bonus;
			cout << "Hours Trainning Required: ";
			cin >> hoursTrainingRequired;
			cout << "Hours Trainning Attended: ";
			cin >> hoursTrainingAttended;
			leader.setMonthlyBonus(bonus);
			leader.setNumHoursTrainingRequired(hoursTrainingRequired);
			leader.setNumHoursTrainingAttended(hoursTrainingAttended);
			leader.setEmpName(empName);
			leader.setEmpNumber(empNum);
			leader.setHireDate(hireDate);
			leader.setShift(shift);
			leader.setHourlyPayRate(hourlyRate);
		} // End if
	} // End while

	// Print results
	cout << "\n\n----------Employee data----------\n";

	cout << "Employee number: " << regularEmp.getEmpNumber() << " (Regular Employee)\n" <<
		"Name: " << regularEmp.getEmpName() << endl <<
		"Hire date: " << regularEmp.getHireDate() << endl << endl;

	cout << "Employee number: " << prodWorker.getEmpNumber() << " (Production Worker)\n" <<
		"Name: " << prodWorker.getEmpName() << endl <<
		"Hire date: " << prodWorker.getHireDate() << endl <<
		"Shift: " << prodWorker.getShift() << endl <<
		"Hourly rate: " << prodWorker.getHourlyPayRate() << endl << endl;

	cout << "Employee number: " << supervisor.getEmpNumber() << " (Shift Supervisor)\n" <<
		"Name: " << supervisor.getEmpName() << endl <<
		"Hire date: " << supervisor.getHireDate() << endl <<
		"Annual salary: " << supervisor.getSalary() << endl <<
		"Annual bonus: " << supervisor.getBonus() << endl << endl;

	cout << "Employee number: " << leader.getEmpNumber() << " (Team Leader)\n" <<
		"Name: " << leader.getEmpName() << endl <<
		"Hire date: " << leader.getHireDate() << endl <<
		"Shift: " << leader.getShift() << endl <<
		"Hourly rate: " << leader.getHourlyPayRate() << endl <<
		"Monthly bonus: " << leader.getMonthlyBonus() << endl <<
		"Number of trainning hours required: " << leader.getNumHoursTrainingRequired() << endl <<
		"Number of trainning hours attended: " << leader.getNumHoursTrainingAttended() << endl << endl;

	return 0;
}